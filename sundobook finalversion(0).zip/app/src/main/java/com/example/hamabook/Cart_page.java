package com.example.hamabook;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.graphics.BitmapFactory;
import java.util.ArrayList;

public class Cart_page extends AppCompatActivity {

    private TextView give_Button;
    private TextView take_Button;
    private TextView my_info_Button;

    private AlertDialog.Builder build;
    private DbHelper mHelper;
    private SQLiteDatabase dataBase;
    EditText editText;
    private ListView listView;
    ArrayList<Favorite_cart> h_info_list;
    DisplayAdapter3 myadapter;
    Favorite_cart myHuman1,myHuman2,myHuman3,myHuman4,myHuman5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_page);

        give_Button = (TextView) findViewById(R.id.give);
        take_Button = (TextView) findViewById(R.id.take);
        my_info_Button = (TextView) findViewById(R.id.my_info);
        listView = (ListView) findViewById(R.id.List_cart);
        mHelper = new DbHelper(this);

        listView = (ListView)findViewById(R.id.List_cart);
        myHuman1 = new Favorite_cart("데이터베이스", "중", "15000", BitmapFactory.decodeResource(getResources(), R.drawable.defaultimage));
        myHuman2 = new Favorite_cart("운영체제", "상", "23000", BitmapFactory.decodeResource(getResources(), R.drawable.defaultimage));
        myHuman3 = new Favorite_cart("알고리즘", "하", "5000", BitmapFactory.decodeResource(getResources(), R.drawable.defaultimage));
        myHuman4 = new Favorite_cart("디지털논리회로", "중", "11000", BitmapFactory.decodeResource(getResources(), R.drawable.defaultimage));
        myHuman5 = new Favorite_cart("웹프로그래밍", "상", "10000", BitmapFactory.decodeResource(getResources(), R.drawable.defaultimage));

        h_info_list = new ArrayList<Favorite_cart>();
        h_info_list.add(myHuman1);
        h_info_list.add(myHuman2);
        h_info_list.add(myHuman3);
        h_info_list.add(myHuman4);
        h_info_list.add(myHuman5);


        myadapter = new DisplayAdapter3(getApplicationContext(),R.layout.book_cart_list, h_info_list);
        listView.setAdapter(myadapter);
        give_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Cart_page.this, MainActivity.class);
                startActivity(i);
            }
        });

        take_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Cart_page.this, Take_page.class);
                startActivity(i);
            }
        });

        my_info_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Cart_page.this, My_info_page.class);
                startActivity(i);
            }
        });


    }
}
