package com.example.hamabook;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


/**
 * Created by IS_LAB on 2016-06-07.
 */
public class Take_detail extends Activity{

    TextView textview1;
    TextView textview2;
    TextView textview3;
    TextView textview4;
    Button btn_buy;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_take_detail);

        final TextView textview1 = (TextView)findViewById(R.id.book_name_take_detail);
        Intent intent1  = getIntent();
        String name1 = intent1.getStringExtra("bname2");
        textview1.setText(name1);

        final TextView textview2 = (TextView)findViewById(R.id.book_status_take_detail);
        Intent intent2  = getIntent();
        String name2 = intent2.getStringExtra("bstatus2");
        textview2.setText(name2);

        final TextView textview3 = (TextView)findViewById(R.id.book_value_take_detail);
        Intent intent3  = getIntent();
        String name3 = intent3.getStringExtra("bvalue2");
        textview3.setText(name3);

        final TextView textview4 = (TextView)findViewById(R.id.book_email_take_detail);
        Intent intent4  = getIntent();
        String name4 = intent4.getStringExtra("email2");
        textview4.setText(name4);

        btn_buy = (Button)findViewById(R.id.button_buy);

        btn_buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Take_detail.this, SendEmailActivity.class);
                i.putExtra("email2", textview4.getText().toString());
                startActivity(i);
            }
        });
        TextView view = (TextView) findViewById(R.id.favorite);



    }
}
