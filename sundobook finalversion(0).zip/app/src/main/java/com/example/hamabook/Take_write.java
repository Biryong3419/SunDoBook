package com.example.hamabook;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Take_write extends AppCompatActivity implements View.OnClickListener {
    private ImageButton back_Button;
    private static final int PICK_FROM_CAMERA = 1;
    private static final int PICK_FROM_GALLERY = 2;
    private ImageView imgview;
    private Button btn_save;
    private EditText book_name,book_status,book_value;
    private DbHelper mHelper;
    private SQLiteDatabase dataBase;
    private String id,bname,bstatus,bvalue;
    private boolean isUpdate;
    private Bundle extras;
    private Bundle extras2;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_take_write);
        back_Button = (ImageButton) findViewById(R.id.back);
        imgview = (ImageView) findViewById(R.id.selectImage);
        Button buttonCamera = (Button) findViewById(R.id.btn_take_camera);
        Button buttonGallery = (Button) findViewById(R.id.btn_select_gallery);


        btn_save=(Button)findViewById(R.id.button_store_take);
        book_name=(EditText)findViewById(R.id.book_name_take);
        book_status=(EditText)findViewById(R.id.book_status_take);
        book_value = (EditText)findViewById(R.id.book_value_take);


        isUpdate=getIntent().getExtras().getBoolean("update");
        if(isUpdate)
        {
            id=getIntent().getExtras().getString("ID");
            bname=getIntent().getExtras().getString("Name");
            bstatus=getIntent().getExtras().getString("Status");
            bvalue=getIntent().getExtras().getString("Value");

            book_name.setText(bname);
            book_status.setText(bstatus);
            book_value.setText(bvalue);

        }

        btn_save.setOnClickListener(this);

        mHelper=new DbHelper(this);


        buttonCamera.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                // 카메라 호출
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI.toString());

                // 이미지 잘라내기 위한 크기
                intent.putExtra("crop", "true");
                intent.putExtra("aspectX", 0);
                intent.putExtra("aspectY", 0);
                intent.putExtra("outputX", 200);
                intent.putExtra("outputY", 150);

                try {
                    intent.putExtra("return-data", true);
                    startActivityForResult(intent, PICK_FROM_CAMERA);
                } catch (ActivityNotFoundException e) {
                    // Do nothing for now
                }
            }
        });

        buttonGallery.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.putExtra("crop", "true");
                intent.putExtra("aspectX", 0);
                intent.putExtra("aspectY", 0);
                intent.putExtra("outputX", 200);
                intent.putExtra("outputY", 150);
                try {
                    intent.putExtra("return-data", true);
                    startActivityForResult(Intent.createChooser(intent,
                            "Complete action using"), PICK_FROM_GALLERY);
                } catch (ActivityNotFoundException e) {

                }
            }
        });


        back_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Take_write.this, Take_page.class);
                startActivity(i);
            }
        });



    }

    public void onClick(View v) {

        bname = book_name.getText().toString().trim();
        bstatus = book_status.getText().toString().trim();
        bvalue = book_value.getText().toString().trim();
        if (bname.length() > 0 && bstatus.length() > 0 && bvalue.length() > 0) {
            saveData2();
        } else {
            android.app.AlertDialog.Builder alertBuilder = new android.app.AlertDialog.Builder(Take_write.this);
            alertBuilder.setTitle("Invalid Data");
            alertBuilder.setMessage("Please, Enter valid data");
            alertBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            alertBuilder.create().show();
        }
        if (v.getId() == R.id.back) {
            Intent it = new Intent(this, Take_page.class);
            startActivity(it);
            finish();
        }
    }
/*
        EditText et_value = (EditText)findViewById(R.id.value);
        String str_value = et_value.getText().toString();

        RadioGroup rg_group = (RadioGroup)findViewById(R.id.book_status);
        String str_group = "";

        if(rg_group.getCheckedRadioButtonId() == R.id.top)
        {
            str_group = "상";
        }
        else if(rg_group.getCheckedRadioButtonId() == R.id.middle)
        {
            str_group = "중";
        }
        else if(rg_group.getCheckedRadioButtonId() == R.id.bottom)
        {
            str_group = "하";
        }

        try {
            dbmgr = new DBManager(this);

            SQLiteDatabase sdb;

            sdb = dbmgr.getWritableDatabase();
            sdb.execSQL("insert into book values('" + str_value + "', '" + str_group + "');");

            dbmgr.close();
        }catch(SQLiteException e)
        {
        }
        Intent it = new Intent (this, MainActivity.class);
        startActivity(it);
        finish();
    }
    */

    protected void onActivityResult(int requestCode,
                                    int resultCode,
                                    Intent data) {

        if (requestCode == PICK_FROM_CAMERA) {
            try {
                extras = data.getExtras();
            }catch(NullPointerException e)
            {
                Toast.makeText (this, "사진을 찍어주세요.", Toast.LENGTH_SHORT).show();
            }
            if (extras != null) {
                Bitmap photo = extras.getParcelable("data");
                imgview.setImageBitmap(photo);
            }
        }
        if (requestCode == PICK_FROM_GALLERY) {
            try {
                extras2 = data.getExtras();
            }
            catch(NullPointerException e)
            {
                Toast.makeText (this, "사진을 선택해주세요.", Toast.LENGTH_SHORT).show();
            }
            if (extras2 != null) {
                Bitmap photo = extras2.getParcelable("data");
                imgview.setImageBitmap(photo);
            }
        }
    }

    private void saveData2(){
        dataBase=mHelper.getWritableDatabase();
        ContentValues values=new ContentValues();

        values.put(DbHelper.KEY_BNAME2,bname);
        values.put(DbHelper.KEY_BSTATUS2,bstatus);
        values.put(DbHelper.KEY_BVALUE2,bvalue);

        System.out.println("");
        if(isUpdate)
        {
            //update database with new data
            dataBase.update(DbHelper.TABLE_NAME2, values, DbHelper.KEY_ID2+"="+id, null);
        }
        else
        {
            //insert data into database
            dataBase.insert(DbHelper.TABLE_NAME2, null, values);
        }
        //close database
        dataBase.close();
        finish();


    }


}








