package com.example.hamabook;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import org.w3c.dom.Text;


/**
 * Created by IS_LAB on 2016-06-07.
 */
public class Give_detail extends Activity{

    TextView textview1;
    TextView textview2;
    TextView textview3;
    TextView textview4;
    Button btn_buy;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_give_detail);

        final TextView textview1 = (TextView)findViewById(R.id.book_name_detail);
        Intent intent1  = getIntent();
        String name1 = intent1.getStringExtra("bname");
        textview1.setText(name1);

        final TextView textview2 = (TextView)findViewById(R.id.book_status_detail);
        Intent intent2  = getIntent();
        String name2 = intent2.getStringExtra("bstatus");
        textview2.setText(name2);

        final TextView textview3 = (TextView)findViewById(R.id.book_value_detail);
        Intent intent3  = getIntent();
        String name3 = intent3.getStringExtra("bvalue");
        textview3.setText(name3);

        final TextView textview4 = (TextView)findViewById(R.id.book_email_detail);
        Intent intent4  = getIntent();
        String name4 = intent4.getStringExtra("email");
        textview4.setText(name4);

        btn_buy = (Button)findViewById(R.id.button_buy);

        btn_buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Give_detail.this, SendEmailActivity.class);
                i.putExtra("email", textview4.getText().toString());
                startActivity(i);
            }
        });

        TextView view = (TextView) findViewById(R.id.favorite);


        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                boolean isSelectedAfterClick = !v.isSelected();
                v.setSelected(isSelectedAfterClick);

                if (isSelectedAfterClick) {
                    TextView tv = (TextView) findViewById(R.id.favorite);
                    tv.setText("♥ ");

                } else {
                    TextView tv = (TextView) findViewById(R.id.favorite);
                    tv.setText("♡ ");
                }
            }
        });
    }
}
