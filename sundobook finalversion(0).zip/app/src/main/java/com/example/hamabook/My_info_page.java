package com.example.hamabook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class My_info_page extends AppCompatActivity {

    private TextView give_Button;
    private TextView take_Button;
    private TextView cart_Button;
    private TextView info_give_Button;
    private TextView info_take_Button;
    private TextView info_correct_Button;
    private TextView info_news_Button;
    private TextView info_email_Button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_info_page);

        give_Button = (TextView) findViewById(R.id.give);
        take_Button = (TextView) findViewById(R.id.take);
        cart_Button = (TextView)findViewById(R.id.cart);

        info_give_Button = (TextView) findViewById(R.id.my_info_give);
        info_take_Button = (TextView) findViewById(R.id.my_info_take);
        info_correct_Button = (TextView) findViewById(R.id.my_info_correct);
        info_news_Button = (TextView) findViewById(R.id.my_info_news);
        info_email_Button = (TextView) findViewById(R.id.my_info_email);


        give_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_page.this,MainActivity.class);
                startActivity(i);
            }
        });

        take_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_page.this,Take_page.class);
                startActivity(i);
            }
        });

        cart_Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_page.this,Cart_page.class);
                startActivity(i);
            }
        });

        info_give_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_page.this,MainActivity.class);
                startActivity(i);

            }
        });

        info_take_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_page.this,Take_page.class);
                startActivity(i);
            }
        });

        info_correct_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_page.this,My_info_correct_page.class);
                startActivity(i);
            }
        });

        info_news_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_page.this,My_info_news_page.class);
                startActivity(i);
            }
        });

        info_email_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_page.this,SendEmailActivity.class);
                startActivity(i);
            }
        });

    }
}
