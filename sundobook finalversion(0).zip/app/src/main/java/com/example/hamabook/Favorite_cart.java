package com.example.hamabook;
import android.graphics.Bitmap;
/**
 * Created by 유병필 on 2016-06-15.
 */
public class Favorite_cart {
    public String name;
    public String gender;
    public String age;
    public Bitmap image;

    Favorite_cart(String name, String gender, String age, Bitmap image){
        this.image = image;
        this.name =name;
        this.gender = gender;
        this.age = age;
    }
}
