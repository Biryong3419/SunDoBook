package com.example.hamabook;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends Activity
{
    private TextView take_Button;
    private TextView my_info_Button;
    private TextView cart_Button;
    private ListView bookList;
    private AlertDialog.Builder build;
    private DbHelper mHelper;
    private SQLiteDatabase dataBase;
    private ArrayList<String> bookId = new ArrayList<String>();
    private ArrayList<String> book_bName = new ArrayList<String>();
    private ArrayList<String> book_bStatus = new ArrayList<String>();
    private ArrayList<String> book_bValue = new ArrayList<String>();
    private ArrayList<String> book_email = new ArrayList<String>();
    DisplayAdapter disadpt = new DisplayAdapter(MainActivity.this,bookId, book_bName, book_bStatus,book_bValue,book_email);
    EditText editText;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        bookList = (ListView) findViewById(R.id.List);
        editText = (EditText) findViewById(R.id.search);
        mHelper = new DbHelper(this);

/*
        displayData();

        editText.addTextChangedListener(new TextWatcher() {

            @Override

            public void beforeTextChanged(CharSequence s, int start, int count, int
                    after) {



            }



            @Override

            public void onTextChanged(CharSequence s, int start, int before, int
                    count) {

                if(s.toString().equals("")){

                    // reset listview

                    displayData();

                }

                else{

                    // perform search

                    searchItem(s.toString());

                }

            }



            @Override

            public void afterTextChanged(Editable s) {



            }

        });
*/
        findViewById(R.id.search_btn).setOnClickListener(new OnClickListener() {

            public void onClick(View v) {

                displayData_search();

            }
        });
        //add new record
        findViewById(R.id.give_write_btn).setOnClickListener(new OnClickListener() {

            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(), Give_write.class);
                i.putExtra("update", false);
                startActivity(i);

            }
        });

        findViewById(R.id.take).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Take_page.class);
                startActivity(i);
            }
        });

        findViewById(R.id.my_info).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, My_info_page.class);
                startActivity(i);
            }
        });

        findViewById(R.id.cart).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Cart_page.class);
                startActivity(i);
            }
        });

        //click to update data
        bookList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {

                TextView tv1 = (TextView) arg0.getChildAt(arg2).findViewById(R.id.txt_bname);
                TextView tv2 = (TextView) arg0.getChildAt(arg2).findViewById(R.id.txt_bstatus);
                TextView tv3 = (TextView) arg0.getChildAt(arg2).findViewById(R.id.txt_bvalue);
                TextView tv4 = (TextView) arg0.getChildAt(arg2).findViewById(R.id.txt_email);
                Intent i = new Intent(MainActivity.this, Give_detail.class);
                i.putExtra("bname", tv1.getText().toString());
                i.putExtra("bstatus",tv2.getText().toString());
                i.putExtra("bvalue", tv3.getText().toString());
                i.putExtra("email", tv4.getText().toString());
                startActivity(i);

            }
        });
        //long click to delete data
        bookList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, final int arg2, long arg3) {

                build = new android.support.v7.app.AlertDialog.Builder(MainActivity.this);
                build.setTitle("Delete " + book_bName.get(arg2) + " " + book_bStatus.get(arg2) + " " + book_bValue.get(arg2));
                build.setMessage("Do you want to change info ?");
                build.setPositiveButton("Delete", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                        Toast.makeText(getApplicationContext(),
                                book_bName.get(arg2) + " "
                                        + book_bStatus.get(arg2) + " "
                                        + book_bValue.get(arg2)
                                        + " is deleted.", Toast.LENGTH_LONG).show();

                        dataBase.delete(
                                DbHelper.TABLE_NAME,
                                DbHelper.KEY_ID + "="
                                        + bookId.get(arg2), null);
                        displayData();
                        dialog.cancel();
                    }
                });

                build.setNegativeButton("Edit", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                        Intent i = new Intent(getApplicationContext(), Give_write.class);
                        i.putExtra("bname", book_bName.get(arg2));
                        i.putExtra("bstatus", book_bStatus.get(arg2));
                        i.putExtra("bvalue", book_bValue.get(arg2));
                        i.putExtra("ID", bookId.get(arg2));
                        i.putExtra("email",book_email.get(arg2));
                        i.putExtra("update", true);
                        startActivity(i);
                    }
                });
                android.support.v7.app.AlertDialog alert = build.create();
                alert.show();

                return true;
            }
        });


    }


    @Override
    protected void onResume() {
        displayData();
        super.onResume();
    }


    /**
     * displays data from SQLite
     */
    private void displayData() {
        dataBase = mHelper.getWritableDatabase();
        Cursor mCursor = dataBase.rawQuery("SELECT * FROM " + DbHelper.TABLE_NAME, null);

        bookId.clear();
        book_bName.clear();
        book_bStatus.clear();
        book_bValue.clear();
        book_email.clear();

        if (mCursor.moveToFirst()) {
            do {
                bookId.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_ID)));
                book_bName.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BNAME)));
                book_bStatus.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BSTATUS)));
                book_bValue.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BVALUE)));
                book_email.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_EMAIL)));

            } while (mCursor.moveToNext());
        }
        DisplayAdapter disadpt = new DisplayAdapter(MainActivity.this,bookId, book_bName, book_bStatus,book_bValue,book_email);
        bookList.setAdapter(disadpt);
        mCursor.close();
    }

    private void displayData_search() {
        dataBase = mHelper.getWritableDatabase();
      //  Cursor mCursor = dataBase.rawQuery("SELECT * FROM "+DbHelper.TABLE_NAME+" WHERE "
        //        +DbHelper.KEY_ID+" = "+DbHelper.KEY_ID+" AND "+DbHelper.KEY_BNAME+
          //
          //     " LIKE  '"+  item +"%'");
        Cursor mCursor = dataBase.rawQuery("SELECT * FROM " + DbHelper.TABLE_NAME, null);

        bookId.clear();
        book_bName.clear();
        book_bStatus.clear();
        book_bValue.clear();
        book_email.clear();
        if(mCursor.getCount()>0)
        {
            while(mCursor.moveToNext())
            {

                if(editText.getText().toString().equals(mCursor.getString(mCursor.getColumnIndex("bname"))))
                {
                    bookId.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_ID)));
                    book_bName.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BNAME)));
                    book_bStatus.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BSTATUS)));
                    book_bValue.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BVALUE)));
                    book_email.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_EMAIL)));
                }
            }

        }

        DisplayAdapter disadpt = new DisplayAdapter(MainActivity.this,bookId, book_bName, book_bStatus,book_bValue,book_email);
        bookList.setAdapter(disadpt);
        mCursor.close();
    }


    public void searchItem(String textToSearch){

        for(String item:book_bName){

            if(!item.contains(textToSearch)){

                book_bName.remove(item);



            }

        }

        disadpt.notifyDataSetChanged();

    }





    /*
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

     

        take_Button = (TextView) findViewById(R.id.take);
        my_info_Button = (TextView) findViewById(R.id.my_info);
        cart_Button = (TextView) findViewById(R.id.cart);

        LinearLayout layout = (LinearLayout) findViewById(R.id.books);


        int i = 0;

        try {
            DBManager dbmgr = new DBManager(this);

            SQLiteDatabase sdb = dbmgr.getReadableDatabase();

            Cursor cursor = sdb.query("book", null, null, null, null, null, null);

            while (cursor.moveToNext()) {
                String name = cursor.getString(0);
                String group = cursor.getString(1);

                TextView tv_list = new TextView(this);

                tv_list.append(name);
                tv_list.setTextSize(20);
                tv_list.setTextColor(Color.rgb(255, 255, 0));
                tv_list.setBackgroundColor(Color.rgb(0, 0, 255));

                layout.addView(tv_list);

                TextView tv_list2 = new TextView(this);

                tv_list2.append(group + "\n");

                layout.addView(tv_list2);

                i++;
            }

            if (i == 0) {
                TextView tv_desc = new TextView(this);
                tv_desc.append("등록된 책이 없습니다.");
                layout.addView(tv_desc);
            }

            cursor.close();
            dbmgr.close();
        } catch (SQLiteException e) {
            TextView tv_err = new TextView(this);
            tv_err.append(e.getMessage());
            layout.addView(tv_err);
        }

        ImageButton btn = (ImageButton) findViewById(R.id.give_write_btn);
        btn.setOnClickListener(this);

        take_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Take_page.class);
                startActivity(i);
            }
        });

        my_info_Button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, My_info_page.class);
                startActivity(i);
            }
        });

        cart_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, Cart_page.class);
                startActivity(i);
            }
        });

        ImageButton b = (ImageButton) findViewById(R.id.give_write_btn);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(

                        getApplicationContext(),
                        Give_write.class);
                startActivity(intent);
            }
        });


    }

    public void onClick(View v)
    {
        Intent it = new Intent(this, Give_write.class);
        startActivity(it);
        finish();
    }
*/
}

