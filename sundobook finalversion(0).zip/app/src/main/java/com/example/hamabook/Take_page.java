package com.example.hamabook;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
public class Take_page extends Activity {

    private TextView give_Button;
    private TextView my_info_Button;
    private TextView cart_Button;

    private ListView bookList;
    private AlertDialog.Builder build;


    private DbHelper mHelper;
    private SQLiteDatabase dataBase;
    EditText editText;

    private ArrayList<String> bookId = new ArrayList<String>();
    private ArrayList<String> book_bName = new ArrayList<String>();
    private ArrayList<String> book_bStatus = new ArrayList<String>();
    private ArrayList<String> book_bValue = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_take_page);

        bookList = (ListView) findViewById(R.id.List_take);
        editText = (EditText) findViewById(R.id.search);
        mHelper = new DbHelper(this);

        //add new record
        findViewById(R.id.take_write_btn).setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent i = new Intent(getApplicationContext(), Take_write.class);
                i.putExtra("update", false);
                startActivity(i);

            }
        });

        //click to update data
        bookList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {

                TextView tv1 = (TextView) arg0.getChildAt(arg2).findViewById(R.id.txt_bname_take);
                TextView tv2 = (TextView) arg0.getChildAt(arg2).findViewById(R.id.txt_bstatus_take);
                TextView tv3 = (TextView) arg0.getChildAt(arg2).findViewById(R.id.txt_bvalue_take);
                Intent i = new Intent(getApplicationContext(), Take_detail.class);
                i.putExtra("bname2", tv1.getText().toString());
                i.putExtra("bstatus2",tv2.getText().toString());
                i.putExtra("bvalue2", tv3.getText().toString());
                startActivity(i);

            }
        });

        //long click to delete data
        bookList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {

            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, final int arg2, long arg3) {

                build = new android.support.v7.app.AlertDialog.Builder(Take_page.this);
                build.setTitle("Delete " + book_bName.get(arg2) + " " + book_bStatus.get(arg2) + " " + book_bValue.get(arg2));
                build.setMessage("Do you want to delete ?");
                build.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                        Toast.makeText(getApplicationContext(),
                                book_bName.get(arg2) + " "
                                        + book_bStatus.get(arg2) + " "
                                        + book_bValue.get(arg2)
                                        + " is deleted.", 3000).show();

                        dataBase.delete(
                                DbHelper.TABLE_NAME2,
                                DbHelper.KEY_ID2 + "="
                                        + bookId.get(arg2), null);
                        displayData();
                        dialog.cancel();
                    }
                });

                build.setNegativeButton("Edit", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                        Intent i = new Intent(getApplicationContext(), Take_write.class);
                        i.putExtra("bname2", book_bName.get(arg2));
                        i.putExtra("bstatus2", book_bStatus.get(arg2));
                        i.putExtra("bvalue2", book_bValue.get(arg2));
                        i.putExtra("update", true);
                        startActivity(i);
                    }
                });
                android.support.v7.app.AlertDialog alert = build.create();
                alert.show();

                return true;
            }
        });

        findViewById(R.id.search_take).setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                displayData_search();

            }
        });

        findViewById(R.id.give).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Take_page.this, MainActivity.class);
                startActivity(i);
            }
        });

        findViewById(R.id.my_info).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(Take_page.this, My_info_page.class);
                startActivity(i);
            }
        });

        findViewById(R.id.cart).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Take_page.this, Cart_page.class);
                startActivity(i);
            }
        });
    }

    @Override
    protected void onResume() {
        displayData();
        super.onResume();
    }
    private void displayData() {
        dataBase = mHelper.getWritableDatabase();
        Cursor mCursor = dataBase.rawQuery("SELECT * FROM " + DbHelper.TABLE_NAME2, null);

        bookId.clear();
        book_bName.clear();
        book_bStatus.clear();
        book_bValue.clear();
        if (mCursor.moveToFirst()) {
            do {
                bookId.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_ID2)));
                book_bName.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BNAME2)));
                book_bStatus.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BSTATUS2)));
                book_bValue.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BVALUE2)));

            } while (mCursor.moveToNext());
        }
        DisplayAdapter2 disadpt = new DisplayAdapter2(Take_page.this,bookId, book_bName, book_bStatus,book_bValue);
        bookList.setAdapter(disadpt);
        mCursor.close();
    }
    private void displayData_search() {
        dataBase = mHelper.getWritableDatabase();

        Cursor mCursor = dataBase.rawQuery("SELECT * FROM " + DbHelper.TABLE_NAME2, null);

        bookId.clear();
        book_bName.clear();
        book_bStatus.clear();
        book_bValue.clear();
        if(mCursor.getCount()>0)
        {
            while(mCursor.moveToNext())
            {

                if(editText.getText().toString().equals(mCursor.getString(mCursor.getColumnIndex("bname2"))))
                {
                    bookId.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_ID2)));
                    book_bName.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BNAME2)));
                    book_bStatus.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BSTATUS2)));
                    book_bValue.add(mCursor.getString(mCursor.getColumnIndex(DbHelper.KEY_BVALUE2)));
                }
            }

        }

        DisplayAdapter2 disadpt = new DisplayAdapter2(Take_page.this,bookId, book_bName, book_bStatus,book_bValue);
        bookList.setAdapter(disadpt);
        mCursor.close();
    }
}
