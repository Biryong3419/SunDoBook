package com.example.hamabook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class My_info_give_page extends AppCompatActivity {

    private ImageButton back_Button;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_info_give_page);

        back_Button = (ImageButton) findViewById(R.id.back);

        back_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_give_page.this,My_info_page.class);
                startActivity(i);
            }
        });


    }
}
