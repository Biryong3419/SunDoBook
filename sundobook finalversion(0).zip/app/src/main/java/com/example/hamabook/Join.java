package com.example.hamabook;


import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;
import org.apache.http.NameValuePair;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class Join extends AppCompatActivity {
    private EditText editTextName;
    private EditText editTextId;
    private EditText editTextStuId;
    private EditText editTextPhone;
    private EditText editTextEmail;
    private EditText editTextDepartment;
    private EditText editTextPassword;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        editTextDepartment = (EditText) findViewById(R.id.user_department);
        editTextName = (EditText) findViewById(R.id.user_name);
        editTextStuId = (EditText) findViewById(R.id.user_stuId);
        editTextPhone = (EditText) findViewById(R.id.user_phone);
        editTextEmail = (EditText) findViewById(R.id.user_email);
        editTextId = (EditText) findViewById(R.id.user_id);
        editTextPassword = (EditText) findViewById(R.id.user_password);
        b = (Button)findViewById(R.id.back);

        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(

                        getApplicationContext(),
                        Login.class);
                startActivity(intent);
            }
        });
    }

  public void insert(View view){
  String user_name = editTextName.getText().toString();
      String user_id = editTextId.getText().toString();
      String user_stuId = editTextStuId.getText().toString();
      String user_department = editTextDepartment.getText().toString();
      String user_email = editTextEmail.getText().toString();
      String user_phone = editTextPhone.getText().toString();
      String user_password = editTextPassword.getText().toString();

      insertToDatabase(user_name, user_id, user_department, user_email, user_phone, user_password, user_stuId);

  }


    private void insertToDatabase(String user_name, String user_id, String user_department,String user_email,String user_phone,String user_password,String user_stuId){

        class InsertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;



            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(Join.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(String... params) {

                try{

                    String user_name = (String)params[0];
                    String user_id = (String)params[1];
                    String user_department = (String)params[2];
                    String user_email = (String)params[3];
                    String user_phone = (String)params[4];
                    String user_password = (String)params[5];
                    String user_stuId = (String)params[6];
                    String link="http://175.204.157.139/insert.php";
                    String data  = URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(user_name, "UTF-8");
                    data += "&" + URLEncoder.encode("user_id", "UTF-8") + "=" + URLEncoder.encode(user_id, "UTF-8");
                    data += "&" + URLEncoder.encode("user_department", "UTF-8") + "=" + URLEncoder.encode(user_department, "UTF-8");
                    data += "&" + URLEncoder.encode("user_email", "UTF-8") + "=" + URLEncoder.encode(user_email, "UTF-8");
                    data += "&" + URLEncoder.encode("user_phone", "UTF-8") + "=" + URLEncoder.encode(user_phone, "UTF-8");
                    data += "&" + URLEncoder.encode("user_password", "UTF-8") + "=" + URLEncoder.encode(user_password, "UTF-8");
                    data += "&" + URLEncoder.encode("user_stuid", "UTF-8") + "=" + URLEncoder.encode(user_stuId, "UTF-8");


                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);
                        startActivity(new Intent(Join.this, Login.class));
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

            }
        }

        InsertData task = new InsertData();
        task.execute(user_name, user_id, user_department, user_email, user_phone, user_password, user_stuId);
    }


}



