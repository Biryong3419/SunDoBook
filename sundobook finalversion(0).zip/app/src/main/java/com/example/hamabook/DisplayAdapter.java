package com.example.hamabook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Locale;

public class DisplayAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<String> id;
    private ArrayList<String> bookName;
    private ArrayList<String> bookStatus;
    private ArrayList<String> bookValue;
    private ArrayList<String> email;
    private ArrayList<ArrayList<String>> booklist;


    public DisplayAdapter(Context c, ArrayList<String> id, ArrayList<String> bname, ArrayList<String> bstatus, ArrayList<String> bvalue, ArrayList<String> email) {
        this.mContext = c;

        this.id = id;
        this.bookName = bname;
        this.bookStatus = bstatus;
        this.bookValue = bvalue;
        this.email = email;
    }

    public int getCount() {
        // TODO Auto-generated method stub
        return id.size();
    }

    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    public View getView(int pos, View child, ViewGroup parent) {
        Holder mHolder;
        LayoutInflater layoutInflater;
        if (child == null) {
            layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            child = layoutInflater.inflate(R.layout.listcell, null);
            mHolder = new Holder();
            mHolder.txt_id = (TextView) child.findViewById(R.id.txt_id);
            mHolder.txt_bName = (TextView) child.findViewById(R.id.txt_bname);
            mHolder.txt_bStatus = (TextView) child.findViewById(R.id.txt_bstatus);
            mHolder.txt_bValue = (TextView) child.findViewById(R.id.txt_bvalue);
            mHolder.txt_email = (TextView) child.findViewById(R.id.txt_email);
            child.setTag(mHolder);
        } else {
            mHolder = (Holder) child.getTag();
        }
        mHolder.txt_id.setText(id.get(pos));
        mHolder.txt_bName.setText(bookName.get(pos));
        mHolder.txt_bStatus.setText(bookStatus.get(pos));
        mHolder.txt_bValue.setText(bookValue.get(pos));
        mHolder.txt_email.setText(email.get(pos));

        return child;
    }

    public class Holder {
        TextView txt_id;
        TextView txt_bName;
        TextView txt_bStatus;
        TextView txt_bValue;
        TextView txt_email;
    }
    

}