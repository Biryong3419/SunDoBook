package com.example.hamabook;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class DisplayAdapter2 extends BaseAdapter {
    private Context mContext;
    private ArrayList<String> id;
    private ArrayList<String> bookName;
    private ArrayList<String> bookStatus;
    private ArrayList<String> bookValue;


    public DisplayAdapter2(Context c, ArrayList<String> id2, ArrayList<String> bname2, ArrayList<String> bstatus2, ArrayList<String> bvalue2) {
        this.mContext = c;

        this.id = id2;
        this.bookName = bname2;
        this.bookStatus = bstatus2;
        this.bookValue = bvalue2;
    }

    public int getCount() {
        // TODO Auto-generated method stub
        return id.size();
    }

    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    public View getView(int pos, View child, ViewGroup parent) {
        Holder mHoler_take;
        LayoutInflater layoutInflater;
        if (child == null) {
            layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            child = layoutInflater.inflate(R.layout.listcell2, null);
            mHoler_take = new Holder();
            mHoler_take.txt_id = (TextView) child.findViewById(R.id.txt_id_take);
            mHoler_take.txt_bName = (TextView) child.findViewById(R.id.txt_bname_take);
            mHoler_take.txt_bStatus = (TextView) child.findViewById(R.id.txt_bstatus_take);
            mHoler_take.txt_bValue = (TextView) child.findViewById(R.id.txt_bvalue_take);
            child.setTag(mHoler_take);
        } else {
            mHoler_take = (Holder) child.getTag();
        }
        mHoler_take.txt_id.setText(id.get(pos));
        mHoler_take.txt_bName.setText(bookName.get(pos));
        mHoler_take.txt_bStatus.setText(bookStatus.get(pos));
        mHoler_take.txt_bValue.setText(bookValue.get(pos));

        return child;
    }

    public class Holder {
        TextView txt_id;
        TextView txt_bName;
        TextView txt_bStatus;
        TextView txt_bValue;
    }


}