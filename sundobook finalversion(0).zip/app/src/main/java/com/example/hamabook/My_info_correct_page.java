package com.example.hamabook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class My_info_correct_page extends AppCompatActivity {

    private EditText editTextStuId;
    private EditText editTextPhone;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private ImageButton back_Button;
    Button b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_info_correct_page);


        editTextStuId = (EditText) findViewById(R.id.user_stuId);
        editTextPhone = (EditText) findViewById(R.id.user_phone);
        editTextEmail = (EditText) findViewById(R.id.user_email);
        editTextPassword = (EditText) findViewById(R.id.user_password);
        b = (Button)findViewById(R.id.cancel);

        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(

                        getApplicationContext(),
                        My_info_page.class);
                startActivity(intent);
            }
        });

        back_Button = (ImageButton) findViewById(R.id.back);

        back_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(My_info_correct_page.this, My_info_page.class);
                startActivity(i);
            }
        });
    }

    public void insert1(View view){


        String user_stuId = editTextStuId.getText().toString();
        String user_email = editTextEmail.getText().toString();
        String user_phone = editTextPhone.getText().toString();
        String user_password = editTextPassword.getText().toString();

        insertToDatabase(user_email, user_phone, user_password, user_stuId);

    }


    private void insertToDatabase(String user_email,String user_phone,String user_password,String user_stuId){

        class InsertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;



            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(My_info_correct_page.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(String... params) {

                try{

                    String user_email = (String)params[0];
                    String user_phone = (String)params[1];
                    String user_password = (String)params[2];
                    String user_stuId = (String)params[3];
                    String link="http://175.204.157.139/insert1.php";
                    String data  = URLEncoder.encode("user_stuId", "UTF-8") + "=" + URLEncoder.encode(user_stuId, "UTF-8");
                    data += "&" + URLEncoder.encode("user_email", "UTF-8") + "=" + URLEncoder.encode(user_email, "UTF-8");
                    data += "&" + URLEncoder.encode("user_phone", "UTF-8") + "=" + URLEncoder.encode(user_phone, "UTF-8");
                    data += "&" + URLEncoder.encode("user_password", "UTF-8") + "=" + URLEncoder.encode(user_password, "UTF-8");



                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;




                    // Read Server Response
                    while((line = reader.readLine()) != null)
                    {
                        sb.append(line);

                        startActivity(new Intent(My_info_correct_page.this, My_info_page.class));
                        break;
                    }
                    return sb.toString();
                }
                catch(Exception e){
                    return new String("Exception: " + e.getMessage());
                }

            }
        }

        InsertData task = new InsertData();
        task.execute( user_email, user_phone, user_password, user_stuId);
    }


}