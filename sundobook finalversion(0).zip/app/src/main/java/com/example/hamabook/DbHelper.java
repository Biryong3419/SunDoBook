package com.example.hamabook;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {
    static String DATABASE_NAME="bookdata";
    public static final String TABLE_NAME="book";
    public static final String KEY_BNAME="bname";
    public static final String KEY_BSTATUS="bstatus";
    public static final String KEY_BVALUE="bvalue";
    public static final String KEY_EMAIL="email";
    public static final String KEY_ID="id";
    public static final String TABLE_NAME2="book2";
    public static final String KEY_BNAME2="bname2";
    public static final String KEY_BSTATUS2="bstatus2";
    public static final String KEY_BVALUE2="bvalue2";
    public static final String KEY_ID2="id2";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE="CREATE TABLE "+TABLE_NAME+" ("+KEY_ID+" INTEGER PRIMARY KEY, "+KEY_BNAME+" TEXT, "+KEY_BSTATUS+" TEXT, "+KEY_BVALUE+" TEXT, "+KEY_EMAIL+" TEXT)";
        String CREATE_TABLE2="CREATE TABLE "+TABLE_NAME2+" ("+KEY_ID2+" INTEGER PRIMARY KEY, "+KEY_BNAME2+" TEXT, "+KEY_BSTATUS2+" TEXT,"+KEY_BVALUE2+" TEXT)";
        db.execSQL(CREATE_TABLE);
        db.execSQL(CREATE_TABLE2);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME2);
        onCreate(db);

    }

}

